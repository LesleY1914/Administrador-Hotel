const fs = require('fs');
const colors = require('colors');
const readline = require('readline');

const hotel = {
  habitaciones: [
    { numero: 101, ocupada: false },
    { numero: 102, ocupada: true },
    { numero: 103, ocupada: false },
  ],
};

const dataFile = 'hotel_data.json';

// Función para mostrar el estado de las habitaciones
function mostrarEstadoHabitaciones() {
  console.log('Estado de las habitaciones:');
  hotel.habitaciones.forEach((habitacion) => {
    const estado = habitacion.ocupada ? 'Ocupada'.red : 'Disponible'.green;
    console.log(`Habitación ${habitacion.numero}: ${estado}`);
  });
}

// Función para guardar los datos en un archivo JSON
function guardarDatos() {
  const dataToSave = JSON.stringify(hotel, null, 2);
  fs.writeFileSync(dataFile, dataToSave);
  console.log('Datos guardados en el archivo hotel_data.json');
}

// Función para cargar los datos desde un archivo JSON
function cargarDatos() {
  if (fs.existsSync(dataFile)) {
    const data = fs.readFileSync(dataFile, 'utf8');
    return JSON.parse(data);
  }
  return hotel; // Si el archivo no existe, utiliza los datos iniciales
}

// Interfaz de línea de comandos
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function mostrarMenu() {
  console.log('*** Sistema de Administración de Hotel ***');
  console.log('1. Ver estado de las habitaciones');
  console.log('2. Reservar habitación');
  console.log('3. Liberar habitación');
  console.log('4. Guardar datos');
  console.log('5. Salir');
  rl.question('Seleccione una opción: ', (opcion) => {
    switch (opcion) {
      case '1':
        mostrarEstadoHabitaciones();
        mostrarMenu();
        break;
      case '2':
        // Lógica para reservar habitación
        console.log('Opción de reserva seleccionada');
        guardarDatos();
        mostrarMenu();
        break;
      case '3':
        // Lógica para liberar habitación
        console.log('Opción de liberación seleccionada');
        guardarDatos();
        mostrarMenu();
        break;
      case '4':
        // Guardar datos en un archivo JSON
        guardarDatos();
        mostrarMenu();
        break;
      case '5':
        console.log('Saliendo del programa');
        rl.close();
        break;
      default:
        console.log('Opción no válida. Intente de nuevo.');
        mostrarMenu();
        break;
    }
  });
}

// Iniciar la aplicación
hotel = cargarDatos(); // Cargar datos desde el archivo (si existe)
mostrarMenu();

