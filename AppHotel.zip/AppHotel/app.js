const colors = require('colors');
const readline = require('readline');


const hotel = {
    habitaciones: [
        { numero: 101, ocupada: false },
        { numero: 102, ocupada: true },
        { numero: 103, ocupada: false },
    ],
};


function mostrarEstadoHabitaciones() {
    console.log('Estado de las habitaciones:');
    hotel.habitaciones.forEach((habitacion) => {
        const estado = habitacion.ocupada ? 'Ocupada'.red : 'Disponible'.green;
        console.log(`Habitación ${habitacion.numero}: ${estado}`);
    });
}


const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
});


function mostrarMenu() {
    console.log('=============================================='.green);
    console.log('      Sistema de Administración de Hotel'.yellow);
    console.log('=============================================='.green);
    console.log('1. Ver estado de las habitaciones');
    console.log('2. Reservar habitación');
    console.log('3. Liberar habitación');
    console.log('4. Salir');
    rl.question('Seleccione una opción: ', (opcion) => {
        switch (opcion) {
            case '1':
                mostrarEstadoHabitaciones();
                mostrarMenu();
                break;
            case '2':

                console.log('Opción de reserva seleccionada');
                mostrarMenu();
                break;
            case '3':

                console.log('Opción de liberación seleccionada');
                mostrarMenu();
                break;
            case '4':
                console.log('Saliendo del programa');
                rl.close();
                break;
            default:
                console.log('Opción no válida. Intente de nuevo.');
                mostrarMenu();
                break;
        }
    });
}


mostrarMenu();